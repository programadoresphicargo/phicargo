<?php
$titulo = "Maniobras en proceso";
require_once('../../includes2/head2.php');
require_once('../../includes2/footer.php');
require_once('contenido.php');
require_once('funciones.php');
require_once('../funciones/funciones.php');
require_once('../detalle_ext/offcanvas.php');