<main id="content" role="main" class="main">
    <div class="content container-fluid">
        <div class="card mb-3 mb-lg-5">
            <div class="card-header">
                <div class="row justify-content-between align-items-center flex-grow-1">
                    <div class="col-md">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="card-header-title text-primary">Maniobras programadas</h1>
                        </div>
                    </div>
                    <div class="col-md">
                        <input type="text" id="fechaInput" placeholder="Seleccionar fecha" class="form-control">
                    </div>
                </div>
            </div>
            <div id="tabla">
            </div>
        </div>
    </div>
    </div>
</main>