<div class="offcanvas offcanvas-end" tabindex="-1" id="detalles_maniobra" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-header">
        <h5 id="offcanvasRightLabel">Detalle de maniobra</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body" id="contenido_central">

        <div id="cargadiv5" class="container mt-5 align-items-center justify-content-center" style="height:100vh;display:flex">
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="sr-only"></span>
                </div>
                <p class="mt-3">Cargando...</p>
            </div>
        </div>

        <div id="contenidomaniobracanvas"></div>
    </div>
</div>