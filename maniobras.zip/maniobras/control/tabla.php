<?php

require_once('../../odoo/odoo-conexion.php');

$fecha_actual = date("Y-m-d");

$kwargs = ['fields' => ['name', 'x_reference', 'x_operador_retiro_id', 'x_mov_bel', 'x_eco_retiro_id', 'x_inicio_programado_retiro', 'x_remolque_1_retiro', 'x_remolque_2_retiro', 'x_dolly_retiro', 'x_status_maniobra_retiro', 'x_tipo_terminal_retiro', 'x_ejecutivo_viaje_bel', 'x_status_maniobra_ingreso', 'x_mov_ingreso_bel_id', 'x_eco_ingreso_id', 'x_terminal_bel', 'x_eco_bel_id', 'x_inicio_programado_retiro', 'x_inicio_programado_ingreso', 'travel_id', 'x_programo_retiro_usuario', 'x_programo_ingreso_usuario', 'store_id', 'partner_id'], 'order' => 'x_inicio_programado_retiro desc'];
$estado = 'activo';

$ids = $models->execute_kw(
    $db,
    $uid,
    $password,
    'tms.waybill',
    'search_read',
    array(array(
        array('x_status_maniobra_retiro', '=', $estado),
    ),),
    $kwargs
);

$retiros = $ids;

$ids = $models->execute_kw(
    $db,
    $uid,
    $password,
    'tms.waybill',
    'search_read',
    array(array(
        array('x_status_maniobra_ingreso', '=', $estado),
    ),),
    $kwargs
);

$ingresos = $ids;

function removeDuplicateTravelIds($data)
{
    $uniqueTravelIds = array();
    $uniqueData = array();

    foreach ($data as $item) {
        if (isset($item['travel_id'])) {
            $travelId = $item['travel_id'];

            if ($travelId !== false || !in_array($travelId, $uniqueTravelIds)) {
                $uniqueData[] = $item;
                if ($travelId !== false) {
                    $uniqueTravelIds[] = $travelId;
                }
            }
        } else {
            $uniqueData[] = $item;
        }
    }

    return $uniqueData;
}

$finalRetiros = $retiros;
$finalIngresos = removeDuplicateTravelIds($ingresos);

$jsonFinal = json_encode(array(
    'Retiro' => $finalRetiros,
    'Ingreso' => $finalIngresos
));

$data = json_decode($jsonFinal, true);

?>
<div class="table-responsive">
    <table class="table table-align-middle table-hover table-sm" id="tabla-datos">
        <thead>
            <tr class="">
                <th data-columna="Sucursal">ID</th>
                <th data-columna="Sucursal">Sucursal</th>
                <th data-columna="Ejecutivo">Ejecutivo</th>
                <th data-columna="Carta Porte">Cliente</th>
                <th data-columna="Remolque">Terminal</th>
                <th data-columna="Carta Porte">Unidad</th>
                <th data-columna="Carta Porte">Operador</th>
                <th data-columna="Carta Porte">Inicio programado</th>
                <th data-columna="Remolque">Contenedor</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($data['Retiro'] as $retiro) { ?>
                <tr data-id="<?php echo $retiro['id'] ?>">
                <?php
                echo '<td>' . $retiro['id'] . '</td>';
                echo '<td><span class="badge bg-success">Retiro</span></td>';
                echo '<td>' . $retiro['x_ejecutivo_viaje_bel'] . '</td>';
                echo '<td>' . $retiro['partner_id'][1] . '</td>';
                echo '<td>' . $retiro['x_mov_bel'] . '</td>';
                echo '<td>' . $retiro['x_eco_retiro_id'][1] . '</td>';
                echo '<td>' . $retiro['x_inicio_programado_retiro'] . '</td>';
                echo '<td>' . $retiro['x_operador_retiro_id'][1] . '</td>';
                echo '<td>' . $retiro['x_reference'] . '</td>';
                echo '</tr>';
            }

            // Imprimir datos de Ingreso
            foreach ($data['Ingreso'] as $ingreso) { ?>
                <tr data-id="<?php echo $ingreso['id'] ?>">
                <?php
                echo '<td>' . $ingreso['id'] . '</td>';
                echo '<td><span class="badge bg-warning">Ingreso</span></td>';
                echo '<td>' . $ingreso['x_ejecutivo_viaje_bel']  . '</td>';
                echo '<td>' . $ingreso['partner_id'][1] . '</td>';
                echo '<td>' . $ingreso['x_terminal_bel'] . '</td>';
                echo '<td>' . $ingreso['x_eco_ingreso_id'][1] . '</td>';
                echo '<td>' . $ingreso['x_inicio_programado_ingreso'] . '</td>';
                echo '<td>' . $ingreso['x_mov_ingreso_bel_id'][1] . '</td>';
                echo '<td>' . $ingreso['x_reference'] . '</td>';
                echo '</tr>';
            } ?>
        </tbody>
    </table>
</div>
<script>
    $('#tabla-datos').on('click', 'tr', function() {
        var dataId = $(this).data('id');
        if ($.isNumeric(dataId)) {
            $("#detalles_maniobra").offcanvas("show");

            $('#cargadiv5').show();
            $("#contenidomaniobracanvas").hide();
            $("#contenidomaniobracanvas").load('../maniobra/index.php', {
                'id': dataId
            }, function() {
                $('#cargadiv5').hide();
                $("#contenidomaniobracanvas").show();
            });

        }
    });
</script>
<?php
require_once('../../search/codigo2.php');
?>