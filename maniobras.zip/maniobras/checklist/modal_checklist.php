<div class="offcanvas offcanvas-end" tabindex="-1" id="modal_checklist_maniobra" aria-labelledby="offcanvasLabel" style="width: 75%;">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasLabel">Checklist</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div id="checklist_maniobra_contenido"></div>
    </div>
</div>