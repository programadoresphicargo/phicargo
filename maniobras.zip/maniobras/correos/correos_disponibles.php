<?php
require_once('../../mysql/conexion.php');
$cn = conectar();
$id_cliente = $_POST['id_cliente'];
$SqlSelect = "SELECT * FROM correos_electronicos where id_cliente = $id_cliente order by correo asc";
$resultado = $cn->query($SqlSelect);
?>
<table class="table table-sm" id="correos_registrados">
    <thead class="thead-light">
        <tr>
            <th scope="col">Dirección</th>
        </tr>
    </thead>
    <tbody id="listado_correos">
        <?php while ($row = $resultado->fetch_assoc()) { ?>
            <tr data-id="<?php echo $row['id_correo'] ?>">
                <td data-search="<?php echo $row['correo'] ?>">
                    <a class="d-flex align-items-center">
                        <?php if ($row['tipo'] == 'Destinatario') { ?>
                            <div class="avatar avatar-soft-primary avatar-circle">
                                <span class="avatar-initials"><?php echo $row['correo'][0] ?> </span>
                            </div>
                        <?php } else { ?>
                            <div class="avatar avatar-soft-success avatar-circle">
                                <span class="avatar-initials"><?php echo $row['correo'][0] ?> </span>
                            </div>
                        <?php } ?>

                        <div class="ms-3">
                            <span class="d-block h5 text-inherit mb-1"><?php echo $row['correo'] ?></span>
                            <?php if ($row['tipo'] == 'Destinatario') { ?>
                                <span class="d-block fs-5 text-body"><span class="badge bg-soft-primary text-primary"><?php echo $row['tipo'] ?></span></span>
                            <?php } else { ?>
                                <span class="d-block fs-5 text-body"><span class="badge bg-soft-success text-success"><?php echo $row['tipo'] ?></span></span>
                            <?php } ?>
                        </div>
                    </a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>