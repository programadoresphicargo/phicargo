<script>
    var selectedOptions = [1];
    var inicio;
    var fin;

    $(document).ready(function() {
        $("#tabla").load('tabla.php');
    });
</script>