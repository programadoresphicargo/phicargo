<?php
require_once('../../tiempo/tiempo.php');

echo imprimirTiempo($_POST['dias']);
