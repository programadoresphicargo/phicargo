<script>
    $(document).ready(function() {
        $("#tabla_contenedores").load('tabla.php');
    });
</script>