<!-- Modal -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="enviar_status_maniobra_modal" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-header">
        <h5 class="modal-title" id="exampleModalLabel">Envío de Actualización de Status</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div id="contenido_status"></div>
    </div>
</div>
<!-- End Modal -->