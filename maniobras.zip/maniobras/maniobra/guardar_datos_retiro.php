<?php
require_once('../../odoo/odoo-conexion.php');
require_once('../../notificaciones/notificaciones.php');
$fechaHora = date("Y-m-d H:i:s");
session_start();

try {
    $id_cp = $_POST['id_cp'];
    $x_mov_bel = $_POST['x_mov_bel'];
    $x_tipo_terminal_retiro = $_POST['x_tipo_terminal_retiro'];

    if ($_POST['x_inicio_programado_retiro'] == '') {
        $x_inicio_programado_retiro = false;
    } else {
        $x_inicio_programado_retiro = $_POST['x_inicio_programado_retiro'];
    }

    if ($_POST['x_solicitud_enlazada'] == '') {
        $x_solicitud_enlazada = false;
    } else {
        $x_solicitud_enlazada = intval($_POST['x_solicitud_enlazada']);
    }

    $x_operador_retiro_id = $_POST['x_operador_retiro_id'];
    $nombre_op = $_POST['nombre_op'];
    $x_eco_retiro = $_POST['nombre_eco'];
    $x_eco_retiro_id = $_POST['x_eco_retiro_id'];
    $x_remolque_1_retiro = $_POST['x_remolque_1_retiro'];
    $x_remolque_2_retiro = $_POST['x_remolque_2_retiro'];
    $x_dolly_retiro = $_POST['x_dolly_retiro'];
    $x_motogenerador_1_retiro = $_POST['x_motogenerador_1_retiro'];
    $x_motogenerador_2_retiro = $_POST['x_motogenerador_2_retiro'];

    $partner_record_ids = [intval($id_cp)];
    $partner_value = [
        'x_operador_retiro_id' => $x_operador_retiro_id,
        'x_operador_retiro' => $nombre_op,
        'x_mov_bel' => $x_mov_bel,
        'x_tipo_terminal_retiro' => $x_tipo_terminal_retiro,
        'x_inicio_programado_retiro' => $x_inicio_programado_retiro,
        'x_eco_retiro' => $x_eco_retiro,
        'x_eco_retiro_id' => $x_eco_retiro_id,
        'x_remolque_1_retiro' => $x_remolque_1_retiro,
        'x_remolque_2_retiro' => $x_remolque_2_retiro,
        'x_dolly_retiro' => $x_dolly_retiro,
        'x_motogenerador_1_retiro' => $x_motogenerador_1_retiro,
        'x_motogenerador_2_retiro' => $x_motogenerador_2_retiro,
        'x_programo_retiro_usuario' => $_SESSION['nombre'],
        'x_programo_retiro_fecha' => $fechaHora,
        'x_solicitud_enlazada' => $x_solicitud_enlazada
    ];
    $values = [$partner_record_ids, $partner_value];

    $cambios = $models->execute_kw($db, $uid, $password, 'tms.waybill', 'write', $values);

    if ($cambios) {
        echo 1;
    } else {
        echo 0;
    }
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
