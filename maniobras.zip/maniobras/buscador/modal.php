<div class="modal fade" id="buscador_cp_sol" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 2000;">
    <div class="modal-dialog modal-xl shadow-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="tabla_solicitudes_cp"></div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>